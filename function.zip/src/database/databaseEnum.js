const { LexModelBuildingService } = require("aws-sdk");

module.exports = {
    SMARTHOME_DATA: "smarthome_data",
    SMARTHOME_DEVICES: "smarthome_devices"
}