function log(message, message1, message2) {
        console.log(message + message1 + message2);
    };
module.exports = log;